using UnityEngine;

public class Activation : MonoBehaviour
{
    public GameObject[] objectsToActivate;

    private void OnDisable()
    {
        // Loop through each object in the array and activate them
        foreach (GameObject obj in objectsToActivate)
        {
            obj.SetActive(true);
        }
    }
}

