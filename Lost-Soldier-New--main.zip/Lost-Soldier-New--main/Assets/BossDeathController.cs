using UnityEngine;
using UnityEngine.SceneManagement;

public class BossDeathController : MonoBehaviour
{
    public GameObject boss;

    private void Update()
    {
        if (boss == null)
        {
            LoadWinMenu();
        }
    }

    private void LoadWinMenu()
    {
        SceneManager.LoadScene("WinMenu");
    }
}

