using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Obstacle"))
        {
            // Collision with an obstacle occurred
            // Stop the enemy's movement
            Rigidbody enemyRigidbody = GetComponent<Rigidbody>();
            enemyRigidbody.velocity = Vector3.zero;
        }
    }
}

