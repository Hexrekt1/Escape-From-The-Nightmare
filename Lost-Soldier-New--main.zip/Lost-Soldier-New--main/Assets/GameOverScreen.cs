using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor;


public class GameOverScreen : MonoBehaviour
{
    public void RestartButton()
    {
        

       SceneManager.LoadScene("BasementMain");

    }
    public void MainMenuButton()
    {
        SceneManager.LoadScene("MainMenu", LoadSceneMode.Single);
        
    }
    
        
}
