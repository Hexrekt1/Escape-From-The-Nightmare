using UnityEngine;

public class PlayerRotationConstraint : MonoBehaviour
{
    private Quaternion initialRotation;

    private void Start()
    {
        // Store the initial rotation of the player
        initialRotation = transform.rotation;
    }

    private void LateUpdate()
    {
        // Reset the rotation of the player to the initial rotation
        transform.rotation = initialRotation;
    }
}

